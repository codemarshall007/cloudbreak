
$('document').ready(function() {
/* handle form validation */
$("#register-form").validate({
rules:
{
user_name: {
required: true,
minlength: 3
},
password: {
required: true,
minlength: 8,
maxlength: 15
},
cpassword: {
required: true,
equalTo: '#password'
},
user_email: {
required: true,
email: true
},
},
messages:
{
user_name: "<span class='w3-text-red w3-medium'>please enter Full name</span>",
password:{
required: "<span class='w3-text-red w3-medium'>please provide a password</span>",
minlength: "<span class='w3-text-red w3-medium'>password at least have 8 characters</span>"
},
user_email: "<span class='w3-text-red w3-medium'>please enter a valid email address</span>",
cpassword:{
required: "<span class='w3-text-red w3-medium'>please retype your password</span>",
equalTo: "<span class='w3-text-red w3-medium'>password doesn't match !</span>"
}
},
submitHandler: submitForm
});
/* handle form submit */
function submitForm() {
var data = $("#register-form").serialize();
$.ajax({
type : 'POST',
url : 'signup.ajax.php',
data : data,
beforeSend: function() {
$("#error").fadeOut();
$("#btn-submit").html('<span class="glyphicon glyphicon-transfer"></span>   sending ...');
},
success : function(response) {
if(response==1){
$("#error").fadeIn(1000, function(){
$("#error").html('<div class="alert alert-danger"> <span class="glyphicon glyphicon-info-sign"></span>   Sorry email already taken !</div>');
$("#btn-submit").html('<span class="glyphicon glyphicon-log-in"></span>   Create Account');
});
} else if(response=="registered"){
$("#btn-submit").html('<img src="ajax-loader.gif" />   Signing Up ...');
window.location = 'welcome.php';
} else {
$("#error").fadeIn(1000, function(){
$("#error").html('<div class="alert alert-danger"><span class="glyphicon glyphicon-info-sign"></span>   '+data+' !</div>');
$("#btn-submit").html('<span class="glyphicon glyphicon-log-in"></span>   Create Account');
});
}
}
});
return false;
}
});