<?php
include_once("functions/connect.php");
if(isset($_POST['btn-save'])) {
    
$user_name = mysqli_real_escape_string($link,$_POST['user_name']);
    
$user_email = mysqli_real_escape_string($link,$_POST['user_email']);
    
$user_password = mysqli_real_escape_string($link,$_POST['password']);
    
$password = md5($user_password);
    
$sql = "SELECT email FROM users WHERE email='$user_email'";
    
$resultset = mysqli_query($link, $sql) or die("database error:". mysqli_error($link));
    
$row = mysqli_num_rows($resultset);
    
if($row !=1){
    
$sql = "INSERT INTO users(name, password, email,date_created) VALUES ('$user_name', '$password', '$user_email',NOW())";
    
mysqli_query($link, $sql) or die("database error:". mysqli_error($link)."qqq".$sql);
    $user_id = mysqli_insert_id($link);
    
    $_SESSION['user_id'] = $user_id;
    
echo "registered";
    
} else {
    
echo "1";
}
    
}
?>