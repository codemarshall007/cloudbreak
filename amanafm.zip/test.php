<!DOCTYPE html>
<html>

<head>
    
    <title>Amana Fm Radio Gombe</title>
   <?php require_once("requirements/style.php");?>
    
    <script src="js/jquery.validate.js" type="text/javascript"></script>
    <script src="js/jquery.validate.min.js" type="text/javascript"></script>
    <script src="js/signup.js" type="text/javascript"></script>
    </head>
    
    <body class='' style="width:400px; background:#eee;">
           <?php require_once("requirements/header.php");?>
<!--
      <table class="w3-center w3-medium w3-margin-top">
               
               <tr>
                   <td class="amana-padding"><a href="index.php">Live FM</a></td>
                   <td class=" amana-padding"><a href="">Feedbacks</a></td>
                   <td class="amana-padding"><a href="programs.php">Programs</a></td>
                   </tr>
               </table>
                <div class="fileUpload w3-border" id="dvPreview">
                <span class="custom-span">+</span>
                <p class="custom-para">Add Image</p>
                <input id="fileupload" type="file" name="fileupload" class="upload" />
                </div>-->

<form class="form-signin" method="post" id="register-form">
<div id="error">
</div>
<div class="form-group">
<input type="text" class="w3-input w3-border-bottom w3-border-green" placeholder="Username" name="user_name" id="user_name" />
</div>
<div class="form-group">
<input type="email" class="w3-input w3-border-bottom w3-border-green" placeholder="Email address" name="user_email" id="user_email" />
<span id="check-e"></span>
</div>
<div class="form-group">
<input type="password" class="w3-input w3-border-bottom w3-border-green" placeholder="Password" name="password" id="password" />
</div>
<div class="form-group">
<input type="password" class="w3-input w3-border-bottom w3-border-green" placeholder="Retype Password" name="cpassword" id="cpassword" />
</div>
<hr />
<div class="form-group">
<button type="submit" class="btn btn-default" name="btn-save" id="btn-submit">
<span class="glyphicon glyphicon-log-in"></span>   Create Account
</button>
</div>
</form>
