<?php
$thispage = "twitter" ; 
$thispage = "home";
$thispage = "facebook";
$thispage = "programs";
$thispage = "";
?>
<?php 
require_once("functions/functions.php");
?><!DOCTYPE html>
<html>

<head>
    
    <title>Amana Fm Radio Gombe</title>
   <?php require_once("requirements/style.php");?>
    <script type="text/javascript" src="js/comment.js"></script>
    </head>
    
    <body class=' bod'>
         
           <?php require_once("requirements/header.php");?>
<div class="main clear-fix">
       <!-- post-->
        
        <div class=" amana-have-margin margin-top">
     <?php

            $posts = getPost();
            
            $mypost = mysqli_fetch_array($posts);
                $num_rows =  mysqli_num_rows($posts);
                $post_id = $mypost['post_id'];
                
                $post_title = $mypost['post_title'];
                
                $post_image = $mypost['post_image'];
                
                $post_body = $mypost['post_body'];
                
                $date_post = $mypost['date_post'];
                if($num_rows != 0){
            
?>
            <div class="row w3-white amana-group amana-no-padding">
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 amana-no-padding amana-border-gray">
                  <img src="uploads/<?php echo $post_image; ?>" class="amana-no-padding col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <div  class="w3-padding">
                  <h5><b><?php echo $post_title; ?></b></h5>
                      <p class="w3-justify"><?php echo $post_body; ?></p>
                      <hr>
                      <div class="row">
                          <div class="col-lg-12 col-md-12 col-sm-12 col-12 img-fluid w3-white amana-no-padding">
                              <ul id="update" class="list-group amana-no-padding no-border">
                                  <?php 
                                  $comment = CommentPreview($post_id);
            
                            while($comments = mysqli_fetch_array($comment)){
                                ?> 
                                <li class="list-group-item amana-no-padding amana-margin-bottom amana-border-gray">
                                    <div class="amana-padding">
                                    
                                            <div class=" col-3 w3-left">
                                                <?php if($comments['avatar']){
                                                ?>
                                            <img src="uploads/<?php echo $comments['avatar']; ?>" class="rounded-circle" width="45" height="45"/>
                                         <?php
                                            }
                                            else{
                                                ?>
                                               <img src="images/img_avatar6.png" class="rounded-circle" width="45" height="45"/>

                                            <?php
                                            }
                                            ?>
                                            </div>
                                            <div class="col-9 w3-right"><span class="lines w3-medium"><b><?php echo $comments['name'];?></b></span>
                                        <span class="w3-medium w3-justify amana-no-padding lines"><?php echo $commen = $comments['comment'];?></span>
                                     <span class="w3-medium"><?php // echo $comment_date = $comments['date_comment'];?></span>
                                            </div>
                                        </div>
                                
                                  </li>
                        
                                  <?php
                                            
                                    }
                                    }else{echo '<h2 class="w3-center w3-medium">This post is not available</h2>';}   
                                  ?>
                              </ul>
                              <div id="flash">
                              </div>
                          <form action="" method="post">
                              <table>
                                  <tr>
                                <td style="width:98%; padding-top:15px; margin-top:10px;">
                              <div class="form-group">
                              <input type="hidden" value="<?php echo $post_id; ?>" id="post_id" name="post_id">
                              <input type="text" class="w3-medium w3-border w3-input amana-round" placeholder="Leave comment" name="comment" id="comment">
                                    </div>
                                  </td>
                                    <td class=" w3-center" style="width:2%; padding-top:10px; margin:0px;">
                                  <input type="image" class="w3-white w3-center submit" style="padding:0px; margin:0px;" src="images/plane.png" width="45" height="45">
                              </td>
                              </tr>
                              </table>
                              </form>
                          </div>
                      </div>
                  </div>
                </div>
            </div>
        </div>
         <?php require_once("requirements/footer.php"); ?>
        </div>

    </body>
</html>
              