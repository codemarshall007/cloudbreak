<?php 
$thispage = "programs";
require_once("functions/functions.php");
?>
<!DOCTYPE html>
<html>

<head>
    
    <title>Amana Fm Radio Gombe</title>
   <?php require_once("requirements/style.php");?>
    </head>
    
    <body class="bod">
<div class="main-container">
           <?php require_once("requirements/header.php");?>
<div class="w3-container">
       <!-- post-->
        
        <div class="amana-have-margin margin-top">            
        <div class="row">
         <div class="col-12 w3-white amana-margin-bottom" style="width:100%; margin:0px padding:0px;"> 
            <h4 class="w3-center" style="width:100%; margin:0px padding:0px;"><b>Programs of the day</b></h4>
    </div>
            <hr>
    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
<?php

$events = UpPrograms();

while($rows = mysqli_fetch_array($events)){
    
    $program_name = $rows['program_name'];
    
    $starting_time = $rows['starting_time'];
    
    $ending_time = $rows['ending_time'];
    
    $date_event = $rows['date_event'];
    
    $conductor = $rows['conductor'];
    
    $avatar = $rows['avatar'];
    ?>

        <div class="row w3-border amana-group w3-white">
        <div class="col-3 w3-left">
    
                <img src="uploads/<?php echo $avatar; ?>" width="70" height="70"  class="rounded-circle">
        </div>
                <div class="col-9 w3-right">
                <h5 class="w3-medium w3-text-khaki lines"><b><?php echo $program_name; ?></b></h5>
                
                <span class="w3-medium lines">With <?php echo $conductor; ?></span>
                <table>
                <tr>
                    <td class="w3-small w3-text-red"><b><?php echo $starting_time.' to '.$ending_time; ?><span class="w3-text-black">&nbsp;&nbsp;Today</span></b></td>
                    </tr>
                </table>
            
            </div>
        </div>
        
    

<?php
}
?>
   </div>

</div>
    </div>
        </div>
         <?php require_once("requirements/footer.php"); ?>
        </div>
    </body>
</html>