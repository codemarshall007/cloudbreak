<?php 
session_start();
//variable for dbase connection

$host_name = 'db710239274.db.1and1.com';

$user_name = 'dbo710239274';

$password = '!@#amana123';

$dbase_name = 'db710239274';

//database connection 

$link = mysqli_connect($host_name,$user_name,$password);

//linking to database

$dbase = mysqli_select_db($link,$dbase_name);