<?php 

//including conection into our page

require_once("connect.php");

//function for fetching events

function UpPrograms(){
    
    //connection link
    
    global $link;
    
    $sql = "SELECT event_id,program_name,starting_time,ending_time,date_event,conductor,avatar FROM events";
    
    $query = mysqli_query($link,$sql);
    
    return $query;
}

//function for fetching post

function MyPosts(){
    
        //connection link
    
    global $link;
    
    $sql = "SELECT post_id,post_body,post_title,post_image,date_post FROM post";
    
    $query = mysqli_query($link,$sql);
    
    return $query;
    
}

function getPost(){
    
       //connection link
    
    global $link;
    
    if(isset($_GET['amanafm'])){
        
        $amanapost =  mysqli_real_escape_string($link,$_GET['amanafm']);
        
        $sql = "SELECT post_id,post_body,post_title,post_image,date_post FROM post WHERE post_id = '$amanapost'";

        $query = mysqli_query($link,$sql);

        return $query;
    }
    
}

//display of comment
function CommentPreview($post_id){
     //connection link
    
    global $link;
    $sql = "SELECT * FROM comments INNER JOIN users ON users.user_id = comments.user_id WHERE post_id = '$post_id'";
    
     $query = mysqli_query($link,$sql);

        return $query;
    
}
function UserProfile($user_id){
     //connection link
    
    global $link;
    $sql = "SELECT * FROM users WHERE user_id = '$user_id'";
    
     $query = mysqli_query($link,$sql);

        return $query;
    
}

function RowCount($post_id){
    
    global $link;
    
    $sql = "select post_id from comments WHERE post_id = '$post_id'";
    
$result = mysqli_query($link,$sql) or die(mysql_error());
    
echo mysqli_num_rows($result);
}

function UploadPro($user_id){
    if(isset($_POST['upload'])){
    global $link;
    $name = mysqli_real_escape_string($link,$_FILES['image']['name']);
$size = mysqli_real_escape_string($link,$_FILES['image']['size']);
if(strlen($name))
{
$path = "uploads/";

$valid_formats = array("jpg", "png", "gif", "bmp");

list($txt, $ext) = explode(".", $name);
if(in_array($ext,$valid_formats))
{
if($size<(1024*1024))
{
$actual_image_name = time().substr(str_replace(" ", "_", $txt), 5).".".$ext;
$tmp = $_FILES['image']['tmp_name'];
if(move_uploaded_file($tmp, $path.$actual_image_name))
{

if(!empty($actual_image_name)){

$sql = "UPDATE users SET avatar = '$actual_image_name' WHERE user_id = '$user_id'";

$query = mysqli_query($link, $sql) or die("database error:". mysqli_error($link)."qqq".$sql);

if($query){

echo "registered";

} else {

echo "1";
}
}
}
else
echo "failed";
}
    
else
echo '<span class="alert-danger">Image file size max 1 MB </span><a href="post.php" class="btn btn-lg btn-md btn-sm btn-success">Click to Make Post</a>';					
}
else
echo '<span class="alert-danger">Invalid file format..</span><a href="post.php" class="btn btn-lg btn-md btn-sm btn-success">Click to Make Post</a>';	
}

else
echo '<span class="alert-danger">Please select image..!</span><a href="post.php" class="btn btn-lg btn-md btn-sm btn-success">Click to Make Post</a>';

exit;    
}
}
