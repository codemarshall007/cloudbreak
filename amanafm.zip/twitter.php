<?php $thispage = "twitter" ; ?>
<!DOCTYPE html>
<html>

<head>
    
    <title>Amana Fm Radio Gombe</title>
   <?php require_once("requirements/style.php");?>
    </head>
    
    <body class="bod">

           <?php require_once("requirements/header.php");?>
        <div class="container margin-top">
          <div class="row">
              <div class="col-12">
                  <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
<a class="twitter-timeline" href="https://twitter.com/amana_fm"><i class="fa fa-twitter"></i>Twittes By Amana FM</a> 
              </div>
        </div>
        </div>
           <?php require_once("requirements/footer.php");?>
        
    </body>
</html>