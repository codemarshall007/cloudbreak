<?php
require_once("functions/connect.php");

if($_POST)
{
if(isset($_SESSION['user_id'])){
    $user_id = mysqli_real_escape_string($link,$_SESSION['user_id']);
$comment = mysqli_real_escape_string($link,$_POST['comment']);
$post_id = mysqli_real_escape_string($link,$_POST['post_id']);

$sql = mysqli_query($link,"insert into comments(post_id,comment,user_id,date_comment) values ('$post_id','$comment','$user_id',NOW())");
    $comment = mysqli_insert_id($link);
   
    if($sql){
        
        $sql = mysqli_query($link,    $sql = "SELECT * FROM comments INNER JOIN users ON users.user_id = comments.user_id WHERE post_id = '$post_id' AND comment_id = '$comment'");
        
        $rows = mysqli_fetch_array($sql);

  
?>
<ul id="update" class="list-group amana-no-padding no-border">
<li class="list-group-item amana-no-padding amana-margin-bottom amana-border-gray">
<div class="amana-padding clear-fix">

<div class=" col-3 w3-left">
<?php if($rows['avatar']){
?>
<img src="uploads/<?php echo $rows['avatar']; ?>" class="rounded-circle" width="45" height="45"/>
<?php
}
else{
?>
<img src="images/img_avatar6.png" class="rounded-circle" width="45" height="45"/>

<?php
}
?>
</div>
<div class="col-9 w3-right"><span class="lines w3-medium"><b><?php echo $rows['name'];?></b></span>
<span class="w3-small w3-justify amana-no-padding lines"><?php echo $rows['comment'];?></span>
<span class="w3-medium"><?php // echo $comment_date = $comments['date_comment'];?></span>
</div>
</div>

</li>
                        
</ul>

<?php
}}else{
?>
<script>window.location = 'login.php'</script>
<?php
}
}

else { }

?>

