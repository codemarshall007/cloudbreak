<nav class="">
<!-- Sidebar/menu -->
<div class="w3-sidebar w3-bar-white  w3-animate-right" style="z-index:3;width:250px;display:none;right:0;" id="mySidebar">
<header class="w3-container w3-green w3-padding w3-xlarge">
<span class="w3-center w3-margin-bottom"><img src="images/logo.png" width="120" height="55"></span>

<a href="javascript:void()" onclick="w3_close()" class="w3-button w3-display-topright w3-xlarge w3-margin-bottom">X</a>
</header>
<br>
<div class="list-group w3-medium amana-menu w3-text-green">
<a href="#" class="list-group-item disabled amana-menu" style="text-align:center; background:#eee;">
More Information
</a>
<a href="#" class="list-group-item w3-text-green amana-menu"><img src="images/01.png" height="35" width="35">&nbsp;&nbsp;Advertise on air</a>
<a href="#" class="list-group-item w3-text-green amana-menu"><img src="images/04.jpg" height="35" width="30">&nbsp;&nbsp;About Amana FM</a>
    <a href="#" class="list-group-item w3-text-green amana-menu">&nbsp;&nbsp;<img src="images/02.jpg" height="35" width="15">&nbsp;&nbsp;About the App</a>

<a href="contactus.php" class="list-group-item w3-text-green amana-menu"><img src="images/03.png" height="35" width="35">&nbsp;&nbsp;Contact Us</a>

</div>
</div>

<!-- Top menu on small screens -->
<header class="container-fluid w3-green w3-padding w3-xlarge navbar-top"  style="width:100%; margin:0px padding:0px;">
<span class="w3-center w3-margin-bottom"><img src="images/logo.png" width="110" height="55"></span>
<a href="javascript:void(0)" class="w3-right w3-button w3-green w3-border-white w3-border w3-circle" onclick="w3_open()">☰</a>

</header>
</nav>
<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
<script>
// Script to open and close sidebar
function w3_open() {
document.getElementById("mySidebar").style.display = "block";
document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
document.getElementById("mySidebar").style.display = "none";
document.getElementById("myOverlay").style.display = "none";
}

</script>