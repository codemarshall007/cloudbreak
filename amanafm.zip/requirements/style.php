 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="css/bootstrap.css" media="all" rel="stylesheet">
    
    <link href="css/bootstrap.min.css" media="all" rel="stylesheet">
    
    <link href="css/bootstrap-grid.css" media="all" rel="stylesheet">
    
    <link href="css/bootstrap-grid.min.css" media="all" rel="stylesheet">
    
    <link href="css/w3.css" media="all" rel="stylesheet">
    
    <link href="css/amana.css" media="all" rel="stylesheet">

    <link rel="stylesheet" href="css/font-awesome.css" type="text/css" />
    
    <link href='https://fonts.googleapis.com/css?family=Barlow Condensed' rel='stylesheet'>
    
    <!-- js requirement -->
    
    <script src="js/jquery-3.2.1.min.js" type="text/javascript"></script>
    <script src="js/jquery.js" type="text/javascript"></script>

    
    <script src="js/bootstrap.js" type="text/javascript"></script>
    
    <script src="js/bootstrap.min.js" type="text/javascript"></script>

    <script src="js/url.js" type="text/javascript"></script>
    
    <!--close js -->