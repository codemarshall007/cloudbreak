       <footer  class="container w3-green navbar">
               <table>
                <tr class="row">
                   <td class="col-3"><a  <?php if($thispage == "home"){echo 'id="active"';}else{} ?> href="index.php"><span class="fa fa-home"></span></a></td>
                  <td class="col-3"><a  <?php if($thispage == "twitter"){echo 'id="active"';}else{} ?> href="twitter.php"><span class="fa fa-twitter"></span></a></td>
                  <td class="col-3"><a  <?php if($thispage == "facebook"){echo 'id="active"';}else{} ?> href="facebook.php"><span class="fa fa-facebook"></span></a></td>
                   <td class="col-3"><a <?php if($thispage == "programs"){echo 'id="active"';}else{} ?> href="programs.php"><span class="fa fa-calendar"></span></a></td>
                  
               </tr>
                </table>
           
        </footer>
