<?php
 require_once 'functions/connect.php';

 if(isset($_POST['btn-login']))
 {
  $user_email = trim($_POST['user_email']);
  $user_password = trim($_POST['password']);
  
  $password = md5($user_password);
  

   $sql = mysqli_query($link,"SELECT password,email,user_id FROM users WHERE email='$user_email' AND password = '$password' LIMIT 1");
 
      if(mysqli_num_rows($sql)){
          
      $row = mysqli_fetch_array($sql);
      
      
   if($row['password']==$password && $row['email']==$user_email){
    
    echo "ok"; // log in
    $_SESSION['user_id'] = $row['user_id'];
    $_SESSION['email'] = $row['email'];
   }
   else{
    
    echo "email or password does not exist."; // wrong details 
   }
    
  }
 }


?>