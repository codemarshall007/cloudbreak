<?php
require_once("functions/functions.php");
?>
<?php
$thispage = "twitter" ; 
$thispage = "home";
$thispage = "facebook";
$thispage = "programs";
$thispage = "";
?>
<!DOCTYPE html>
<html>

<head>
    
    <title>Amana Fm Radio Gombe</title>
   <?php 
    require_once("requirements/style.php");
    if(isset($_SESSION['user_id'])){
         $user_id = $_SESSION['user_id'];
    }
    
    ?>
    </head>
    
    <body class=' bod'>
 <!-- post-->
        <div class="main-container">
           <?php require_once("requirements/header.php");?>

      
        <div class="amana-have-margin">
            <div class="row amana-group amana-no-padding">
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 amana-no-padding w3-white amana-group w3-border">
                  <?php
                  $result = UserProfile($user_id);
                  
                  $rows = mysqli_fetch_array($result);
                  
                  $user_id = $rows['user_id'];
                  $name = $rows['name'];
                  ?>
                  <h4 class="w3-medium w3-center">Welcome to Amana FM <strong class="w3-text-khaki"><?php echo $name; ?></strong></h4>
                  <p class="w3-center w3-text-red">Upload your picture for better experince</p>
                  <form action="" method="post" enctype="multipart/form-data">
                      <?php UploadPro($user_id); ?>
                      <div class="row">
                            <div class="col-12"><div id="dvPreview" style="width:100px; height:100px;"></div></div>

                          <div class="col-12">
                  <div class="form-group">
                <input  type="hidden" name="user_id" value="<?php echo $user_id; ?> " />
                <input id="fileupload" type="file" name="image" class="w3-input w3-border-bottom w3-border-green" />
                </div>
                 </div>
                      </div>
                  <div class="form-group w3-center">
                  <button name="upload" class="w3-btn w3-green w3-medium" type="submit">Upload Image</button>
                  </div>
                  </form>
                </div>
            </div>
        </div>
        </div>
                   <?php require_once("requirements/footer.php");?>

        <script type="text/jscript" src="js/jquery.js"></script>
        <script>
        $('document').ready(function() {
            
    $("#fileupload").change(function () {
        $("#dvPreview").html("");
        var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
        if (regex.test($(this).val().toLowerCase())) {
        
                if (typeof (FileReader) != "undefined") {
                    $("#dvPreview").show();
                    $("#dvPreview").append("<img />");
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $("#dvPreview img").attr("src", e.target.result);
                    }
                    reader.readAsDataURL($(this)[0].files[0]);
                } else {
                    alert("This browser does not support FileReader.");
                }
            
        }
         else {
            alert("Please upload a valid image file.");
        }
    });
});
        </script>
    </body>
</html>
