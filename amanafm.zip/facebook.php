<?php $thispage = "facebook"; ?>
<!DOCTYPE html>
<html>

<head>
    
    <title>Amana Fm Radio Gombe</title>
   <?php require_once("requirements/style.php");?>

    </head>
    
    <body class=' bod'>
           <?php require_once("requirements/header.php");?>
        <div class="container margin-top">
            <div class="row">
                <div class="col-12">
 <div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.11&appId=154250318425297';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

    
     <div class="fb-page" data-href="https://www.facebook.com/prymemarketplace" data-tabs="timeline" data-small-header="false" data-adapt-container-width="false" data-hide-cover="false" data-show-facepile="false"><blockquote cite="https://www.facebook.com/prymemarketplace" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/prymemarketplace">Pryme Market</a></blockquote></div>
                </div>
            </div>
        </div>
               <?php require_once("requirements/footer.php");?>
    </body>
</html>
