<?php
$thispage = "twitter" ; 
$thispage = "home";
$thispage = "facebook";
$thispage = "programs";
$thispage = "";
?>
<!DOCTYPE html>
<html>

<head>
    
    <title>Amana Fm Radio Gombe</title>
   <?php require_once("requirements/style.php");?>
     <script src="js/jquery.validate.js" type="text/javascript"></script>
    <script src="js/jquery.validate.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="js/contact.js"></script>
    </head>
    
    <body class='bod'>
           <?php require_once("requirements/header.php");?>
<div class="w3-container margin-top amana-have-margin w3-card">
       
           
        <div class="row">

        <header class="col-12 w3-white"  style="text-align:center;">
            <h1><i class="fa fa-phone-square " style="font-size:120px;"></i></h1>
        </header>
        <div class="w3-white col-12">
            <br>
<br>
       <form class="form-signin" method="post" id="contact-form">
        
        <div id="error">
        <!-- error will be shown here ! -->
        </div>
        
        <div class="form-group"><b class="w3-medium">Email</b>
        <input type="email" class="w3-input w3-border-bottom w3-border-green w3-medium" placeholder="Email address" name="email" id="email" />
        <span id="check-e"></span>
        </div>
        
        <div class="form-group"><b class="w3-medium">Phone Number</b>
        <input type="text" class="w3-input w3-border-bottom w3-border-green w3-medium" placeholder="Phone Number" name="phone_num" id="phone_num" />
        </div>
           <div class="form-group"><b class="w3-medium">Name</b>
        <input type="text" class="w3-input w3-border-bottom w3-border-green w3-medium" placeholder="Name" name="name" id="name" />
        </div>
           <div class="form-group"><b class="w3-medium">Message</b>
               <textarea class="w3-input w3-border-bottom w3-border-green w3-medium" rows="3" placeholder="message" name="msg" id="msg"></textarea>
        </div>
       
      <hr />
        <div class="row">
            <div class="col-6">
        <div class="form-group">
            <button type="submit" class="w3-btn w3-green" name="btn-save" id="btn-submit">
      <span class="glyphicon glyphicon-log-in"></span> &nbsp; Send Message
   </button> 
        </div>
            </div>
           </div>
      </form>

    </div>
    
                 </div>
             </div>
                  <?php require_once("requirements/footer.php"); ?>

            
</body>
</html>
