<?php 
$thispage = "home";
require_once("functions/functions.php");
?><!DOCTYPE html>
<html>

<head>
    
    <title>Amana Fm Radio Gombe</title>
   <?php require_once("requirements/style.php");?>
    </head>
    
    <body class="bod">
<div class="main-container">
           <?php require_once("requirements/header.php");?>
<div class="w3-container">
       <!-- post-->
        
        <div class="amana-have-margin margin-top">            
        <div class="row">
         <div class="col-12 w3-white amana-margin-bottom" style="width:100%; margin:0px padding:0px;"> 
            <h4 class="w3-center" style="width:100%; margin:0px padding:0px;"><b><i class="fa fa-headphones"></i>Listening to Amana FM Live<script src="//myradiostream.com/embed/codemarshall"></script></b></h4>
    </div>
            <hr>
    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
      
            <?php

            $posts = MyPosts();
            
            while($mypost = mysqli_fetch_array($posts)){
                
                $post_id = $mypost['post_id'];
                
                $post_title = $mypost['post_title'];
                
                $post_image = $mypost['post_image'];
                
                $post_body = $mypost['post_body'];
                
                $date_post = $mypost['date_post'];
                
            
?>
            <div class="row amana-group amana-no-padding">
              <div class="col-lg-12 col-md-12 col-sm-12 col-12 amana-no-padding w3-white amana-group w3-border">
                  <img src="uploads/<?php echo $post_image; ?>" class="amana-no-padding col-lg-12 col-md-12 col-sm-12 col-xs-12" height="350">
                  <div  class="w3-padding">
                  <h5><b><?php echo $post_title; ?></b></h5>
                      <p class="w3-justify">
                      
                       <?php
                            if (strlen($post_body) > 150) {
                            echo  substr($post_body,0,150) . "..."; }else{echo $post_body;} ?>
                      </p>
                      <hr>
                  <div class="row">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-6 w3-large"><?php RowCount($post_id); ?>&nbsp;&nbsp;&nbsp;<i class="fa fa-comment w3-xlarge"></i></div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 amana-read w3-large">
                          <a href="readmore.php?amanafm=<?php echo $post_id; ?>" class="pull-right">Read More</a></div>
                      </div>
                      
                </div>
            </div>
            </div>
        <?php
            }
            ?>
        </div>
        </div>
                      </div>
            </div>
 <?php require_once("requirements/footer.php"); ?>
        </div>
    </body>
</html>