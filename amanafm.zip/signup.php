<?php 
$thispage = "twitter" ; 
$thispage = "home";
$thispage = "facebook";
$thispage = "programs";
require_once("functions/functions.php");
?><!DOCTYPE html>
<html>

<head>
    
    <title>Amana Fm Radio Gombe</title>
   <?php require_once("requirements/style.php");?>
    
    <script src="js/jquery.validate.js" type="text/javascript"></script>
    <script src="js/jquery.validate.min.js" type="text/javascript"></script>
    <script src="js/signup.js" type="text/javascript"></script>
    </head>
    
    <body class='' style="max-width:400px; background:#eee;">
           <?php require_once("requirements/header.php");?>
<div class="container margin-top w3-card amana-have-margin">
       
           
        <div class="row">

           <header class="col-12 w3-white"  style="text-align:center;">
            <h1><i class="fa fa-user " style="font-size:120px;"></i></h1>
        </header>

        <div class="col-12 w3-white">
            <br>
            <form class="form-signin" method="post" id="register-form">
<div id="error">
</div>
<div class="form-group"><b class="w3-medium">Name</b>
<input type="text" class="w3-input w3-border-bottom w3-border-green w3-medium" placeholder="Full name" name="user_name" id="user_name" />
</div>
<div class="form-group"><b class="w3-medium">Email</b>
<input type="email" class="w3-input w3-border-bottom w3-border-green w3-medium" placeholder="Email address" name="user_email" id="user_email" />
<span id="check-e"></span>
</div>
<div class="form-group"><b class="w3-medium">Create Password</b>
<input type="password" class="w3-input w3-border-bottom w3-border-green w3-medium" placeholder="Password" name="password" id="password" />
</div>
<div class="form-group"><b class="w3-medium">Retype Password</b>
<input type="password" class="w3-input w3-border-bottom w3-border-green w3-medium" placeholder="Retype Password" name="cpassword" id="cpassword" />
</div>
<hr />
                <div class="row">
            <div class="col-6">
<div class="form-group">
<button type="submit" class="w3-btn w3-green w3-medium" name="btn-save" id="btn-submit">
<span class="glyphicon glyphicon-log-in"></span>   Create Account
</button>
</div>
                 </div>
              <div class="col-6 w3-medium"><i class="fa fa-unlock"></i><a href="login.php">Sign In</a></div>
           </div>
</form>
            </div>
            </div>
        </div>
     <?php require_once("requirements/footer.php"); ?>
</div>
    </body>
</html>