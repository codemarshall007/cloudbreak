<?php
$thispage = "twitter" ; 
$thispage = "home";
$thispage = "facebook";
$thispage = "programs";
?>
<!DOCTYPE html>
<html>

<head>
    
    <title>Amana Fm Radio Gombe</title>
   <?php require_once("requirements/style.php");?>
     <script src="js/jquery.validate.js" type="text/javascript"></script>
    <script src="js/jquery.validate.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="js/login.js"></script>
    </head>
    
    <body class=' bod'>
           <?php require_once("requirements/header.php");?>
<div class="container margin-top w3-card amana-have-margin">
       
           
        <div class="row">

        <header class="col-12 w3-white"  style="text-align:center;">
            <h1><i class="fa fa-unlock " style="font-size:120px;"></i></h1>
        </header>
        <div class="w3-white col-12">
            <br>
<br>
       <form class="form-signin" method="post" id="login-form">
        
        <div id="error">
        <!-- error will be shown here ! -->
        </div>
        
        <div class="form-group"><b class="w3-medium">Email</b>
        <input type="email" class="w3-input w3-border-bottom w3-border-green w3-medium" placeholder="Email address" name="user_email" id="user_email" />
        <span id="check-e"></span>
        </div>
        
        <div class="form-group"><b class="w3-medium">Password</b>
        <input type="password" class="w3-input w3-border-bottom w3-border-green w3-medium" placeholder="Password" name="password" id="password" />
        </div>
       
      <hr />
        <div class="row">
            <div class="col-6">
        <div class="form-group">
            <button type="submit" class="w3-btn w3-green" name="btn-login" id="btn-login">
      <span class="glyphicon glyphicon-log-in"></span> &nbsp; Sign In
   </button> 
        </div>
            </div>
              <div class="col-6 w3-medium"><i class="fa fa-user"></i><a href="signup.php">Create Account</a></div>
           </div>
      </form>

    </div>
    
                 </div>
             </div>
                  <?php require_once("requirements/footer.php"); ?>

            
</body>
</html>
